<?php
error_reporting(E_ALL);
ini_set('display_errors',1);

if (isset($_GET["move"])){
	$move = $_GET["move"];
	if ($move === "true") {
		$command = "sudo python /var/www/python/start.py; sudo python /var/www/python/tuomas.py 2>&1";
	} else {
		$command = "sudo python /var/www/python/stop.py 2>&1";
	}
} else {
	$command = "sudo python /var/www/python/stop.py 2>&1";
}
$output = shell_exec($command);
echo "<pre>$output</pre>";
?>
