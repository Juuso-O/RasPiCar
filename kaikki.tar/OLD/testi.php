<?php
error_reporting(E_ALL);
ini_set('display_errors',1);

$kulma = $_GET["kulma"];

if ($kulma > 0 && $kulma < 0.0026) {
	$command = "sudo python /var/www/python/PVM.py $kulma 2>&1";
} else {
	$command = "sudo python /var/www/python/PVM.py 2>&1";
	//$command = "sh /home/pi/PVM.sh 2>&1";
}
$output = shell_exec($command);
echo "<pre>$output</pre>";
?>
