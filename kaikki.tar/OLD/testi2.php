<?php
error_reporting(E_ALL);
ini_set('display_errors',1);

while(true) {
$command = "sudo python /var/www/python/PVM.py 2>&1";
$output = shell_exec($command);
echo "<pre>$output</pre>";
$command = "sudo python /var/www/python/PVM.py 0.002 2>&1";
$output = shell_exec($command);
echo "<pre>$output</pre>";
$command = "sudo python /var/www/python/PVM.py 2>&1";
$output = shell_exec($command);
echo "<pre>$output</pre>";
$command = "sudo python /var/www/python/PVM.py 0.001 2>&1";
$output = shell_exec($command);
echo "<pre>$output</pre>";
$command = "sudo python /var/www/python/PVM.py 2>&1";
$output = shell_exec($command);
echo "<pre>$output</pre>";
}
?>
