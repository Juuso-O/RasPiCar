
import RPi.GPIO as GPIO
import time
import sys

GPIO.setmode(GPIO.BCM)

#Set up header pin 11 as an output
print "Setup pin 11"
varLOOPS=10
varCOUNTER=0
GPIO.setup(17, GPIO.OUT)
varTOTAL = 0.02
varON = 0.00168

varARGS = len(sys.argv)
if varARGS>1 :
    print(str(sys.argv[1]))
    varON = float(str(sys.argv[1]))

while varCOUNTER < varLOOPS :
    GPIO.output(17, True)
    time.sleep(varON)
    GPIO.output(17, False)
    time.sleep(varTOTAL-varON)
    varCOUNTER = varCOUNTER + 1
