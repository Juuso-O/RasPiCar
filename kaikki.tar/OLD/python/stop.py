
import RPi.GPIO as GPIO

GPIO.setmode(GPIO.BCM)

print "Stop pin 24"
GPIO.setup(24, GPIO.OUT)
GPIO.output(24, False)
