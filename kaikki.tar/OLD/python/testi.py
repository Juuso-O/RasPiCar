
import RPi.GPIO as GPIO
import time

GPIO.setmode(GPIO.BCM)

#Set up header pin 11 as an output
print "Setup pin 24"
var=1
GPIO.setup(24, GPIO.OUT)
maxAika=0.01
onAika=0.005
offAika=maxAika - onAika
while var==1 :
#    print "Pinni paalle"
    GPIO.output(24, True)
    time.sleep(onAika)
#    print "Pinni pois"
    GPIO.output(24, False)
    time.sleep(offAika)
