
import RPi.GPIO as GPIO

varPinNumber = 23
GPIO.setmode(GPIO.BCM)

print "Start pin " + str(varPinNumber)
GPIO.setup(varPinNumber, GPIO.OUT)
GPIO.output(varPinNumber, True)
