sudo python /var/www/tuomas.py
