<?php
$var = true;
$tmp = exec("sudo python /var/www/testi/python.py $var");
echo $tmp;
?>
