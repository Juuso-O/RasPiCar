<?php
shell_exec("sh /var/www/startUp.sh");
?>
