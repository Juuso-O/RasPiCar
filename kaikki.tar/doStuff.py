#Argumentteina kulma mihin kaannetaan
#Ilman argumentteja keskiasentoon

import RPi.GPIO as GPIO
import time
import sys

GPIO.setmode(GPIO.BCM)
GPIO.setup(24, GPIO.OUT)
GPIO.setup(17, GPIO.OUT)

# Ikiloop
while True :

	# Liikkumisshit
	fMove = open('move', 'r')
	varMove = fMove.read()
	fMove.close()
	if varMove == "true" :
		print "Start pin 24"
		GPIO.output(24, True)
	else :
		print "Stop pin 24"
		GPIO.output(24, False)
	
	# Kaantymisshit
	fTurn = open('turn', 'r')
	varTurn = fTurn.read()
	fTurn.close()
	
	if varTurn != "" :
		varON = float(varTurn)
	else :
		varON = 0.0015
	
	varLOOPS=10
	varCOUNTER=0
	varTOTAL = 0.02
	
	while varCOUNTER < varLOOPS :
	    GPIO.output(17, True)
	    time.sleep(varON)
	    GPIO.output(17, False)
	    time.sleep(varTOTAL-varON)
	    varCOUNTER = varCOUNTER + 1

	time.sleep(0.1)
